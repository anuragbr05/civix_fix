# 📚 CivicFix - Complete Source Code Documentation

## 📁 Project Structure

```
HACKATHON/
├── server.js              # Main backend server
├── package.json           # Project dependencies
├── .env                   # Environment variables
├── models/
│   └── Complaint.js       # Database schema
├── routes/
│   └── complaints.js      # API routes
└── public/
    ├── index.html         # Home page
    ├── report.html        # Report issue page
    ├── track.html         # Track complaint page
    ├── admin.html         # Admin dashboard
    ├── css/
    │   └── styles.css     # All styling
    └── uploads/           # Photo storage
```

---

## 1️⃣ SERVER.JS - Main Backend Server

**Purpose:** Entry point of the application. Sets up Express server, connects database, and handles all routes.

**Technology:** Node.js + Express.js

```javascript
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());                              // Allow cross-origin requests
app.use(express.json());                      // Parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Parse form data

// Serve static files (HTML, CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// MongoDB Connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/civic-platform';
mongoose.connect(MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(() => console.log('DEMO MODE - Using in-memory storage'));

// API Routes
const complaintsRouter = require('./routes/complaints');
app.use('/api/complaints', complaintsRouter);

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
```

---

## 2️⃣ ROUTES/COMPLAINTS.JS - API Routes

**Purpose:** Handles all complaint-related API endpoints.

**Technology:** Express.js Router + Multer for file uploads

```javascript
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');

// In-memory storage for demo
let complaints = [];

// Configure file upload
const storage = multer.diskStorage({
  destination: 'public/uploads/',
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

// Generate unique complaint ID
function generateComplaintId() {
  return 'CIV-' + Date.now().toString(36).toUpperCase();
}

// POST - Create new complaint
router.post('/', upload.single('photo'), async (req, res) => {
  const { issueType, description, latitude, longitude, address } = req.body;
  
  const complaint = {
    complaintId: generateComplaintId(),
    issueType,
    description,
    location: { latitude: parseFloat(latitude), longitude: parseFloat(longitude), address },
    photo: req.file ? '/uploads/' + req.file.filename : '',
    status: 'pending',
    createdAt: new Date()
  };
  
  complaints.push(complaint);
  res.status(201).json({ success: true, data: { complaintId: complaint.complaintId } });
});

// GET - List all complaints
router.get('/', (req, res) => {
  res.json({ success: true, data: complaints });
});

// GET - Statistics
router.get('/stats', (req, res) => {
  res.json({
    success: true,
    data: {
      total: complaints.length,
      pending: complaints.filter(c => c.status === 'pending').length,
      inProgress: complaints.filter(c => c.status === 'in-progress').length,
      resolved: complaints.filter(c => c.status === 'resolved').length
    }
  });
});

// GET - Single complaint
router.get('/:id', (req, res) => {
  const complaint = complaints.find(c => c.complaintId === req.params.id);
  if (!complaint) return res.status(404).json({ success: false });
  res.json({ success: true, data: complaint });
});

// PATCH - Update complaint
router.patch('/:id', (req, res) => {
  const index = complaints.findIndex(c => c.complaintId === req.params.id);
  if (index === -1) return res.status(404).json({ success: false });
  complaints[index] = { ...complaints[index], ...req.body };
  res.json({ success: true, data: complaints[index] });
});

module.exports = router;
```

---

## 3️⃣ GPS LOCATION CODE (report.html)

**Purpose:** Capture user's live GPS location automatically.

**Technology:** Browser Geolocation API (JavaScript)

```javascript
// Get user's live GPS location
navigator.geolocation.getCurrentPosition(
  function(position) {
    // Success - got coordinates
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    
    // Store in hidden form fields
    document.getElementById('latitude').value = latitude;
    document.getElementById('longitude').value = longitude;
    
    // Reverse geocoding - convert to address
    fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`)
      .then(res => res.json())
      .then(data => {
        document.getElementById('locationDisplay').value = data.display_name;
      });
  },
  function(error) {
    alert('Location error: ' + error.message);
  },
  { enableHighAccuracy: true }
);
```

---

## 4️⃣ MAP DISPLAY CODE (Leaflet.js)

**Purpose:** Show complaint locations on interactive map.

**Technology:** Leaflet.js + OpenStreetMap

```javascript
// Initialize map
const map = L.map('adminMap').setView([20.5937, 78.9629], 5);

// Add OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

// Add markers for complaints
complaints.forEach(c => {
  const marker = L.marker([c.location.latitude, c.location.longitude])
    .addTo(map)
    .bindPopup(`<b>${c.issueType}</b><br>Status: ${c.status}`);
});
```

---

## 5️⃣ TECHNOLOGY STACK

| Component | Technology |
|-----------|------------|
| Frontend | HTML5, CSS3, JavaScript |
| Backend | Node.js, Express.js |
| Database | MongoDB / In-Memory |
| Maps | Leaflet.js + OpenStreetMap |
| GPS | Browser Geolocation API |
| File Upload | Multer |
| Styling | CSS Glassmorphism |

---

## 🚀 How to Run

```bash
npm install
npm start
# Open http://localhost:3000
```

## 🔑 Admin Login
- Username: admin
- Password: admin123
