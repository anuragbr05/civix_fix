const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// In-memory storage for demo mode
let complaints = [];

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, '..', 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadsDir);
    },
    filename: function (req, file, cb) {
        const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
        cb(null, uniqueName);
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|gif|webp/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        if (extname && mimetype) {
            return cb(null, true);
        }
        cb(new Error('Only image files are allowed!'));
    }
});

// Generate unique complaint ID
function generateComplaintId() {
    const prefix = 'CIV';
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${timestamp}-${random}`;
}

// CREATE - Submit a new complaint
router.post('/', upload.single('photo'), async (req, res) => {
    try {
        console.log('📥 Received complaint submission');
        console.log('Body:', req.body);

        const { issueType, description, latitude, longitude, address, citizenName, citizenPhone, citizenEmail } = req.body;

        if (!issueType || !description || !latitude || !longitude) {
            console.log('❌ Missing required fields');
            return res.status(400).json({
                success: false,
                message: 'Missing required fields: issueType, description, latitude, longitude'
            });
        }

        const now = new Date();
        const complaint = {
            _id: `mem_${Date.now()}`,
            complaintId: generateComplaintId(),
            issueType,
            description,
            location: {
                latitude: parseFloat(latitude),
                longitude: parseFloat(longitude),
                address: address || ''
            },
            citizenName: citizenName || 'Anonymous',
            citizenPhone: citizenPhone || '',
            citizenEmail: citizenEmail || '',
            photo: req.file ? `/uploads/${req.file.filename}` : '',
            status: 'pending',
            priority: 'medium',
            assignedTo: '',
            resolutionPhoto: '',
            resolutionNotes: '',
            createdAt: now,
            updatedAt: now
        };

        complaints.push(complaint);
        console.log('✅ Complaint saved:', complaint.complaintId);

        res.status(201).json({
            success: true,
            message: 'Complaint submitted successfully',
            data: {
                complaintId: complaint.complaintId,
                status: complaint.status,
                createdAt: complaint.createdAt
            }
        });
    } catch (error) {
        console.error('❌ Error creating complaint:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to submit complaint: ' + error.message
        });
    }
});

// READ - Get all complaints
router.get('/', async (req, res) => {
    try {
        const { status, issueType, limit = 100, skip = 0 } = req.query;

        let results = [...complaints];
        if (status) results = results.filter(c => c.status === status);
        if (issueType) results = results.filter(c => c.issueType === issueType);

        results.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        const total = results.length;
        const paged = results.slice(parseInt(skip), parseInt(skip) + parseInt(limit));

        res.json({
            success: true,
            data: paged,
            total,
            limit: parseInt(limit),
            skip: parseInt(skip)
        });
    } catch (error) {
        console.error('Error fetching complaints:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch complaints'
        });
    }
});

// READ - Get complaint statistics
router.get('/stats', async (req, res) => {
    try {
        const total = complaints.length;
        const pending = complaints.filter(c => c.status === 'pending').length;
        const inProgress = complaints.filter(c => c.status === 'in-progress').length;
        const resolved = complaints.filter(c => c.status === 'resolved').length;
        const rejected = complaints.filter(c => c.status === 'rejected').length;

        const byType = {};
        complaints.forEach(c => {
            byType[c.issueType] = (byType[c.issueType] || 0) + 1;
        });

        res.json({
            success: true,
            data: {
                total,
                pending,
                inProgress,
                resolved,
                rejected,
                recentCount: total,
                byType
            }
        });
    } catch (error) {
        console.error('Error fetching stats:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch statistics'
        });
    }
});

// READ - Get single complaint by ID
router.get('/:id', async (req, res) => {
    try {
        const complaint = complaints.find(c => c.complaintId === req.params.id);

        if (!complaint) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        res.json({
            success: true,
            data: complaint
        });
    } catch (error) {
        console.error('Error fetching complaint:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch complaint'
        });
    }
});

// UPDATE - Update complaint status
router.patch('/:id', upload.single('resolutionPhoto'), async (req, res) => {
    try {
        const { status, priority, assignedTo, resolutionNotes } = req.body;

        const index = complaints.findIndex(c => c.complaintId === req.params.id);
        if (index === -1) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        if (status) complaints[index].status = status;
        if (priority) complaints[index].priority = priority;
        if (assignedTo) complaints[index].assignedTo = assignedTo;
        if (resolutionNotes) complaints[index].resolutionNotes = resolutionNotes;
        if (req.file) complaints[index].resolutionPhoto = `/uploads/${req.file.filename}`;
        complaints[index].updatedAt = new Date();

        console.log('✅ Complaint updated:', req.params.id);

        res.json({
            success: true,
            message: 'Complaint updated successfully',
            data: complaints[index]
        });
    } catch (error) {
        console.error('Error updating complaint:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update complaint'
        });
    }
});

// DELETE - Delete a complaint
router.delete('/:id', async (req, res) => {
    try {
        const index = complaints.findIndex(c => c.complaintId === req.params.id);
        if (index === -1) {
            return res.status(404).json({
                success: false,
                message: 'Complaint not found'
            });
        }

        complaints.splice(index, 1);
        console.log('✅ Complaint deleted:', req.params.id);

        res.json({
            success: true,
            message: 'Complaint deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting complaint:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete complaint'
        });
    }
});

module.exports = router;
